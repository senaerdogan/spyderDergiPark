A python code for searching and downloading articles from DergiPark. 

First, install a driver from the driver links listed here: https://pypi.org/project/selenium/

Further developments are on the way.
